package taskmanager.api;

import java.time.LocalDateTime;
/**
 * <b>System Entity: WeatherForecast</b>
 * <p>This class acts as an immutable data carrier representing the atmospheric 
 * conditions for a specific location and time. It is used by the scheduling 
 * engine to perform weather-aware task evaluations.</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Immutability:</b> All state fields are marked as final and initialized 
 *       via the constructor, ensuring thread-safety across reactive streams.</li>
 *   <li><b>Data Integrity:</b> Provides read-only access to meteorological 
 *       parameters including temperature and precipitation probability.</li>
 * </ul>
 */
public class WeatherForecast {
    /** <b>Field:</b> Geographic name of the city or area for this forecast. */
    private final String location;
    /** <b>Field:</b> The exact timestamp the forecast is valid for. */
    private final LocalDateTime time;
    /** <b>Field:</b> Ambient temperature measured in degrees Celsius. */
    private final double temperatureCelsius;
    /** <b>Field:</b> Qualitative description of weather (e.g., "Sunny", "Rainy"). */
    private final String condition;
    /** <b>Field:</b> Likelihood of precipitation ranging from 0.0 to 1.0. */
    private final double precipitationProbability;
    /**
     * <b>Constructor: Weather Data Initialization</b>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>'location' and 'time' must not be null.</li>
     *   <li>'precipitationProbability' should be within the range [0.0, 1.0].</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>A WeatherForecast instance is created with an immutable state.</li>
     * </ul>
     * 
     * @param location Name of the location.
     * @param time Forecast timestamp.
     * @param temperatureCelsius Temperature in Celsius.
     * @param condition Weather condition string.
     * @param precipitationProbability Probability of rain/snow (0.0 to 1.0).
     */
    public WeatherForecast(String location, LocalDateTime time,
                           double temperatureCelsius,
                           String condition,
                           double precipitationProbability) {
        this.location = location;
        this.time = time;
        this.temperatureCelsius = temperatureCelsius;
        this.condition = condition;
        this.precipitationProbability = precipitationProbability;
    }
    /**
     * <b>Role:</b> Location Accessor.
     * @return The string representing the geographic location.
     */
    public String getLocation() {
        return location;
    }
    /**
     * <b>Role:</b> Timestamp Accessor.
     * @return The {@link LocalDateTime} of the forecast.
     */
    public LocalDateTime getTime() {
        return time;
    }
    /**
     * <b>Role:</b> Temperature Accessor.
     * @return Current temperature in Celsius.
     */
    public double getTemperatureCelsius() {
        return temperatureCelsius;
    }
    /**
     * <b>Role:</b> Condition Accessor.
     * @return Descriptive weather string.
     */
    public String getCondition() {
        return condition;
    }
    /**
     * <b>Role:</b> Precipitation Accessor.
     * @return The probability value for precipitation.
     */
    public double getPrecipitationProbability() {
        return precipitationProbability;
    }
}