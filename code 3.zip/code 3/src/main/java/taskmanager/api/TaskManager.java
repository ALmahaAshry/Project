package taskmanager.api;
import java.util.List;
import reactor.core.publisher.Mono;
import taskmanager.impl.DefaultTaskManagerBuilder;
/**
 * <b>Interface Purpose: Main System Facade</b>
 * <p>Acts as the primary entry point and unified interface for the Smart Task Manager API. 
 * It abstracts the complexity of the underlying subsystems (Task Management, Weather Services, 
 * and Scheduling) providing a clean API for client interactions.</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Orchestration:</b> Coordinates interactions between task storage and external weather APIs.</li>
 *   <li><b>Abstraction:</b> Hides implementation details of task persistence and reactive streams.</li>
 *   <li><b>Design Pattern:</b> Implements the Facade pattern and provides a static Factory for the Builder.</li>
 * </ul>
 * 
 * @see taskmanager.api.Task
 * @see taskmanager.api.WeatherForecast
 * @see taskmanager.api.SchedulePlanner
 */
/**
 * Main facade for the Smart Task Manager.
 * Other developers will use this to interact with the system.
 */
public interface TaskManager {
    /**
     * <b>Role:</b> Synchronous Task Registration.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The 'task' object must be instantiated and contain a valid unique ID.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>The task is successfully added to the internal data structure.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Modifies the state of the task collection within the implementation class.</li>
     * </ul>
     * 
     * @param task The {@link Task} entity to be persisted.
     */
    void addTask(Task task);
    /**
     * <b>Role:</b> Task Removal.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>'taskId' must exist within the current task registry.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>The associated task is removed from the system state.</li>
     * </ul>
     * 
     * @param taskId The unique string identifier of the task to be deleted.
     */
    void removeTask(String taskId);
    /**
     * <b>Role:</b> State Retrieval.
     * @return A {@link List} containing all currently registered {@link Task} objects.
     */
    List<Task> getTasks();
    /**
     * <b>Role:</b> Asynchronous Weather Data Retrieval.
     * <p>Fetches real-time meteorological data without blocking the calling thread.</p>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a {@link Mono} that will emit a {@link WeatherForecast} upon completion.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Triggering the resulting Mono will initiate external Network I/O.</li>
     * </ul>
     * 
     * @param location String representing the target geographic area.
     * @return A reactive Mono wrapper for the weather data.
     */
    // Fetches weather data asynchronously without blocking
    Mono<WeatherForecast> fetchWeather(String location); 
    /**
     * <b>Role:</b> Service Provider Accessor.
     * @return An instance of the associated {@link SchedulePlanner} implementation.
     */
    SchedulePlanner getPlanner();
    /**
     * <b>Role:</b> Static Factory Method.
     * <p>Provides access to the builder implementation required to configure and 
     * instantiate the TaskManager.</p>
     * 
     * @return A new instance of {@link TaskManagerBuilder} (specifically {@link DefaultTaskManagerBuilder}).
     */
    // Static factory method to get a new instance of a builder
    static TaskManagerBuilder builder() {
        return new DefaultTaskManagerBuilder(); // Creates and returns the hidden implementation of the builder
    }
    /**
     * <b>Interface Purpose: Fluent Builder Pattern</b>
     * <p>Defines the configuration steps required to construct a valid TaskManager instance.</p>
     */
    // A nested interface defining the steps to build a TaskManager
    interface TaskManagerBuilder {
        /**
         * <b>Role:</b> Security Configuration.
         * <b>Side Effects:</b> Stores the API key for future weather service requests.
         * @param apiKey The secret key for the weather provider.
         * @return The current builder instance for method chaining.
         */
        TaskManagerBuilder withWeatherApiKey(String apiKey); // stores the key.
        /**
         * <b>Role:</b> Storage Configuration.
         * @param path The filesystem path for persistence (optional).
         * @return The current builder instance for method chaining.
         */
        TaskManagerBuilder withStoragePath(String path);  // optional;stores the file path, if needed
        /**
         * <b>Role:</b> Final Object Instantiation.
         * <b>Pre-conditions:</b> API key must have been provided via 'withWeatherApiKey'.
         * @return A fully configured concrete implementation of {@link TaskManager}.
         */
        TaskManager build();//creates the final TaskManager object.
    }
}