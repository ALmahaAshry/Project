package taskmanager.api;

import java.time.LocalDateTime;
/**
 * <b>Class Purpose:</b>
 * Represents a core business entity within the system that encapsulates all attributes 
 * of a schedulable task. This class follows the JavaBean pattern for state management 
 * while maintaining an immutable unique identifier.
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li>Data Encapsulation: Fields are kept private to ensure state control through accessors and mutators.</li>
 *   <li>Identity Integrity: The 'id' field is final, preventing modification after instantiation.</li>
 *   <li>Environmental Metadata: Includes a flag to indicate sensitivity to external weather conditions.</li>
 * </ul>
 */
public class Task {
    /** <b>Field:</b> Unique identifier. Immutable once assigned during construction. */
    private final String id;
    /** <b>Field:</b> Descriptive title for the task. */
    private String title;
    /** <b>Field:</b> Narrative details or requirements of the task. */
    private String description;
    /** <b>Field:</b> The designated temporal deadline or scheduled timestamp. */
    private LocalDateTime dueDateTime;
    /** <b>Field:</b> Boolean flag indicating if logic should consider weather forecasts. */
    private boolean weatherSensitive;
/**
     * Constructs a new Task instance with core mandatory attributes.
     * 
     * <p><b>Method Role:</b> Constructor</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>'id' and 'title' should not be null for proper system indexing.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>An instance of {@link Task} is initialized with the provided state.</li>
     * </ul>
     * 
     * @param id Unique ID.
     * @param title Task label.
     * @param dueDateTime Scheduled time.
     * @param weatherSensitive Sensitivity flag.
     */
    public Task(String id, String title, LocalDateTime dueDateTime, boolean weatherSensitive) {
        this.id = id;
        this.title = title;
        this.dueDateTime = dueDateTime;
        this.weatherSensitive = weatherSensitive;
    }
    /**
     * <b>Role:</b> Identifier Accessor.
     * @return The immutable ID assigned at instantiation.
     */
    public String getId() {
        return id;
    }
    /**
     * <b>Role:</b> Title Accessor.
     * @return Current title string.
     */
    public String getTitle() {
        return title;
    }
    /**
     * <b>Role:</b> Title Mutator.
     * <b>Side Effects:</b> Updates the internal 'title' state.
     * @param title New title for the task.
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * <b>Role:</b> Description Accessor.
     * @return Detailed task narrative (may be null if not set).
     */
    public String getDescription() {
        return description;
    }
    /**
     * <b>Role:</b> Description Mutator.
     * <b>Side Effects:</b> Updates the internal 'description' state.
     * @param description New narrative content.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * <b>Role:</b> Temporal Accessor.
     * @return The scheduled {@link LocalDateTime}.
     */
    public LocalDateTime getDueDateTime() {
        return dueDateTime;
    }
    /**
     * <b>Role:</b> Temporal Mutator.
     * @param dueDateTime New target timestamp.
     */
    public void setDueDateTime(LocalDateTime dueDateTime) {
        this.dueDateTime = dueDateTime;
    }
    /**
     * <b>Role:</b> Sensitivity Accessor.
     * @return true if the task requires weather forecast evaluation.
     */
    public boolean isWeatherSensitive() {
        return weatherSensitive;
    }
    /**
     * <b>Role:</b> Sensitivity Mutator.
     * <b>Pre-conditions:</b> Value must be boolean.
     * <b>Side Effects:</b> Changes scheduling behavior in {@link SchedulePlanner}.
     * @param weatherSensitive Updated flag status.
     */
    public void setWeatherSensitive(boolean weatherSensitive) {
        this.weatherSensitive = weatherSensitive;
    }
}