package taskmanager.api;

import java.util.List;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
/**
 * <b>Interface Purpose: Reactive Task Operations</b>
 * <p>Defines the contract for asynchronous task management. This service utilizes 
 * Project Reactor types (Mono and Flux) to ensure all data operations are 
 * non-blocking and stream-oriented.</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Concurrency:</b> Designed to execute operations without blocking the main thread.</li>
 *   <li><b>Data Streaming:</b> Provides mechanisms to retrieve tasks as discrete events (Flux) or collective snapshots (Mono).</li>
 *   <li><b>Lifecycle Management:</b> Handles the persistence lifecycle (Create, Read, Delete) for {@link Task} entities.</li>
 * </ul>
 * 
 * @see taskmanager.api.Task
 * @see reactor.core.publisher.Mono
 * @see reactor.core.publisher.Flux
 */
/**
 * Service for task operations.
 */
public interface TaskService {
    /**
     * <b>Role:</b> Asynchronous Persistence (Add).
     * <p>Registers a new task in the system repository.</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The 'task' parameter must not be null.</li>
     *   <li>The task must have a unique identifier that does not collide with existing entries.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns an empty {@link Mono} that completes successfully upon storage.</li>
     *   <li>Emits an error signal if the task data is invalid.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Modifies the internal state of the implementation's data store.</li>
     * </ul>
     * 
     * @param task The {@link Task} object to be persisted.
     * @return A Mono signalling completion or error.
     */
    Mono<Void> addTask(Task task);
    /**
     * <b>Role:</b> Asynchronous Removal.
     * <p>Deletes a task from the system based on its unique ID.</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>'taskId' must be a valid, existing identifier in the system.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a {@link Mono} that completes when the deletion is finalized.</li>
     *   <li>Emits an error (e.g., TaskNotFoundException) if the ID does not exist.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Permanent removal of the task from the system registry.</li>
     * </ul>
     * 
     * @param taskId The unique string key for the target task.
     * @return A Mono signalling completion.
     */
    Mono<Void> removeTask(String taskId);
    /**
     * <b>Role:</b> Reactive Retrieval (Single).
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Emits the found {@link Task} object.</li>
     *   <li>Emits an empty Mono or error if no match is found.</li>
     * </ul>
     * 
     * @param taskId The ID of the task to locate.
     * @return A Mono containing the task.
     */
    Mono<Task> findTaskById(String taskId);
    /**
     * <b>Role:</b> Reactive Stream Retrieval (Multiple).
     * <p>Provides a continuous stream of all tasks currently managed by the service.</p>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a {@link Flux} emitting tasks as they are retrieved from the store.</li>
     * </ul>
     * 
     * @return A Flux of {@link Task} objects.
     */
    Flux<Task> findAllTasks();
    /**
     * <b>Role:</b> Reactive Collective Retrieval.
     * <p>Collects all managed tasks into a single list structure before emitting.</p>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a {@link Mono} that emits a full {@link List} once all data is gathered.</li>
     * </ul>
     * 
     * @return A Mono containing a list of all tasks.
     */
    Mono<List<Task>> findAllTasksAsList();
}