package taskmanager.api;


import java.util.List;
import reactor.core.publisher.Mono;
/**
 * <b>Interface Purpose:</b>
 * This interface defines the core contract for weather-aware scheduling logic within the system. 
 * It acts as a specialized service to evaluate a collection of tasks against meteorological data 
 * to determine optimal execution times or potential risks.
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li>Decision Logic: Implementing strategies to compare task requirements with weather constraints.</li>
 *   <li>Reactive Processing: Utilizing {@link Mono} to handle asynchronous evaluation results.</li>
 *   <li>Recommendation Generation: Mapping evaluation results into {@link ScheduleRecommendation} data carriers.</li>
 * </ul>
 * 
 * @see taskmanager.api.Task
 * @see taskmanager.api.WeatherForecast
 * @see taskmanager.api.ScheduleRecommendation
 */
public interface SchedulePlanner {
     /**
     * Evaluates a list of tasks against a pre-fetched weather forecast.
     * 
     * <p><b>Method Role:</b> Synchronous Logic / Reactive Wrapper</p>
     * 
     * <p><b>Execution Logic:</b></p>
     * 1. Iterates through the provided task list.
     * 2. Checks the 'weatherSensitive' flag of each task against the forecast parameters.
     * 3. Generates a status (e.g., SAFE, RISKY, TOO_HOT) for each task.
     * 4. Collects results into a list emitted via a Mono.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The task list must not be null (may be empty).</li>
     *   <li>The forecast object must be populated with valid meteorological data for the relevant timeframe.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a Mono emitting a List of recommendations.</li>
     *   <li>The original Task and WeatherForecast objects remain immutable.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>None. This is designed as a pure transformation function.</li>
     * </ul>
     * 
     * @param tasks A {@link List} of {@link Task} objects requiring evaluation.
     * @param forecast A {@link WeatherForecast} object containing the environmental state to compare against.
     * @return A {@link Mono} emitting a list of generated schedule recommendations.
     */
    Mono<List<ScheduleRecommendation>> suggestSchedule(
            List<Task> tasks,
            WeatherForecast forecast);
     /**
     * Fetches weather data for a specific location and then suggests a schedule for the tasks.
     * 
     * <p><b>Method Role:</b> Asynchronous Orchestration</p>
     * 
     * <p><b>Execution Logic:</b></p>
     * 1. Initiates an asynchronous request to fetch weather data for the specified location.
     * 2. Upon successful fetch, pipelines the resulting forecast into the evaluation logic.
     * 3. Emits the final recommendation list.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The location string must be a valid city name or coordinate supported by the weather provider.</li>
     *   <li>The task list must not be null.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a reactive stream (Mono) that will eventually yield scheduling recommendations.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Network I/O: Subscription to the returned Mono will trigger external API calls for weather retrieval.</li>
     * </ul>
     * 
     * @param tasks A {@link List} of {@link Task} objects to evaluate.
     * @param location A {@link String} representing the geographic location for which weather should be fetched.
     * @return A {@link Mono} that completes with a list of recommendations once weather data is retrieved and processed.
     */
    Mono<List<ScheduleRecommendation>> suggestScheduleForLocation(
            List<Task> tasks,
            String location);
}

