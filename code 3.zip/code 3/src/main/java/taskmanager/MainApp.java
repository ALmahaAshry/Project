package taskmanager;


import java.time.LocalDateTime;
import taskmanager.api.Task;
import taskmanager.api.TaskManager;
import taskmanager.ui.SmartTaskManagerFrame;
/**
 * <b>System Entry Point:</b>
 * This class serves as the primary bootstrapping mechanism for the Smart Task Manager 
 * application. It encapsulates the initialization logic required to transition the 
 * system from a dormant state to an operational state.
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li>API Facade Construction: Utilizing the Builder pattern to instantiate TaskManager.</li>
 *   <li>Data Seeding: Generating transient Task objects for system verification.</li>
 *   <li>UI Thread Management: Transferring control from the main thread to the Event Dispatch Thread (EDT).</li>
 * </ul>
 * 
 * @see taskmanager.api.TaskManager
 * @see taskmanager.api.Task
 * @see taskmanager.ui.SmartTaskManagerFrame
 */
public class MainApp {
/**
     * Executes the application startup sequence.
     * 
     * <p><b>Method Role:</b> Application Bootstrap</p>
     * 
     * <p><b>Execution Pipeline:</b></p>
     * 1. Configures the {@link TaskManager} with a concrete Weather API key.
     * 2. Creates immutable {@link Task} records with specific temporal and environmental constraints.
     * 3. Synchronously injects tasks into the manager's internal state.
     * 4. Initializes the top-level Swing container (Frame).
     * 5. Asynchronously invokes the UI visibility to ensure thread-safety.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The runtime environment must support Abstract Window Toolkit (AWT) and Swing.</li>
     *   <li>The specified Weather API key must be structurally valid for external service calls.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>The TaskManager instance is successfully instantiated and populated.</li>
     *   <li>The Swing Event Dispatch Thread (EDT) is active and controlling the UI lifecycle.</li>
     *   <li>The SmartTaskManagerFrame is allocated in memory and rendered on the screen.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Console I/O: Outputs the current size of the task collection to the standard output stream.</li>
     *   <li>Concurrency: Spawns the EDT thread for GUI rendering, decoupling it from the main application thread.</li>
     * </ul>
     * 
     * @param args Array of strings representing command-line arguments (not processed in this implementation).
     */
    public static void main(String[] args) {
        // Build the TaskManager (students will implement DefaultTaskManager)
        // Initialize the core system facade
        TaskManager tm = TaskManager.builder()
                .withWeatherApiKey("a885d3236fb957e3ab6abe72b776aabf")
                .build();

        // Add a couple of test tasks
        // Seed initial data for testing system logic
        Task task1 = new Task(
                "task-001",
                "Morning run",
                LocalDateTime.now().plusHours(2),
                true
        );
        Task task2 = new Task(
                "task-002",
                "Coding session",
                LocalDateTime.now().plusHours(4),
                false
        );
        // Populate manager state
        tm.addTask(task1);
        tm.addTask(task2);
        // Verification log for system state
        System.out.println("Tasks loaded: " + tm.getTasks().size());

        // Wire this to the Swing UI
        // UI Initialization and Dependency Injection
        SmartTaskManagerFrame frame = new SmartTaskManagerFrame(tm);
        // Ensure UI thread safety via invokeLater
        javax.swing.SwingUtilities.invokeLater(() -> frame.setVisible(true));
    }
}