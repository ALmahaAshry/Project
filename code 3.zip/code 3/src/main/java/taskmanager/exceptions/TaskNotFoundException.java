package taskmanager.exceptions;
/**
 * <b>Exception Purpose:</b>
 * This class is a custom unchecked exception thrown when a retrieval operation fails 
 * to locate a {@link taskmanager.api.Task} using a specific identifier. It ensures 
 * that the system can provide precise feedback regarding which resource was missing.
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>State Propagation:</b> Passes a formatted error message containing the 
 *       missing taskId to the superclass for logging and UI display.</li>
 *   <li><b>Control Flow:</b> Being a {@link RuntimeException}, it allows for 
 *       un-checked error handling across reactive streams.</li>
 * </ul>
 * 
 * @see java.lang.RuntimeException
 */
public class TaskNotFoundException extends RuntimeException {
    /**
     * <b>Constructor: Resource Error Initialization</b>
     * <p>Constructs a new exception by formatting a message with the provided taskId.</p>
     * 
     * <p><b>Method Role:</b> Constructor</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The 'taskId' should be the identifier that caused the lookup failure 
     *       in the task registry.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>An instance of TaskNotFoundException is created with the detailed 
     *       message: "Task not found: [taskId]".</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Captures the execution stack trace to assist in debugging data 
     *       consistency issues.</li>
     * </ul>
     * 
     * @param taskId The unique identifier of the task that was not found.
     */
    public TaskNotFoundException(String taskId) {
        super("Task not found: " + taskId);
    }
}

