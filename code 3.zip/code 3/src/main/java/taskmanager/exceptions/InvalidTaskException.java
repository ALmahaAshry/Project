package taskmanager.exceptions;
/**
 * <b>Exception Purpose:</b>
 * This class is a custom unchecked exception designed to be thrown when a {@link taskmanager.api.Task} 
 * fails validation logic. It indicates that the task data provided (e.g., title, date) does 
 * not meet the system's structural or business requirements.
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Error Handling:</b> Extends {@link RuntimeException} to allow for flexible 
 *       error propagation without forcing mandatory try-catch blocks.</li>
 *   <li><b>Messaging:</b> Facilitates the passage of detailed error strings to the 
 *       GUI for user feedback.</li>
 * </ul>
 * 
 * @see java.lang.RuntimeException
 */
public class InvalidTaskException extends RuntimeException {
    /**
     * <b>Constructor: Error Initialization</b>
     * <p>Constructs a new exception with a specific detail message explaining the 
     * validation failure.</p>
     * 
     * <p><b>Method Role:</b> Constructor</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>A non-null 'message' string should be provided to describe the exact 
     *       nature of the invalid data.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>An instance of InvalidTaskException is created and populated with the 
     *       provided error message.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Captures the current thread's stack trace at the moment of instantiation.</li>
     * </ul>
     * 
     * @param message The descriptive error message.
     */
    public InvalidTaskException(String message) {
        super(message);
    }
}