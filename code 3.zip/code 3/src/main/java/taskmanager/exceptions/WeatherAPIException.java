package taskmanager.exceptions;
/**
 * <b>Exception Purpose:</b>
 * This class is a custom unchecked exception thrown when an error occurs during 
 * communication with an external Weather API. It acts as a wrapper for lower-level 
 * network or parsing errors, providing a high-level context for the application's 
 * error-handling subsystem.
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Error Chaining:</b> Supports the "cause" mechanism to preserve the original 
 *       stack trace (e.g., from an IOException or API response error).</li>
 *   <li><b>Fault Tolerance:</b> Designed to be caught by the UI layer to inform 
 *       the user of service outages or configuration issues.</li>
 * </ul>
 * 
 * @see java.lang.RuntimeException
 * @see taskmanager.api.TaskManager#fetchWeather(String)
 */
public class WeatherAPIException extends RuntimeException {
    /**
     * <b>Constructor: Integration Error Initialization</b>
     * <p>Constructs a new exception with a specific error message and the underlying 
     * cause of the failure.</p>
     * 
     * <p><b>Method Role:</b> Constructor (Chained Exception)</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>A descriptive 'message' should be provided to explain the API failure context.</li>
     *   <li>The 'cause' should be the original {@link Throwable} caught during the API call.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>An instance of WeatherAPIException is created, linking the application-level 
     *       message with the root cause for debugging.</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Captures the stack trace, including the linked cause's trace, to 
     *       facilitate end-to-end troubleshooting.</li>
     * </ul>
     * 
     * @param message The descriptive error message.
     * @param cause   The underlying cause of the exception (e.g., a network error).
     */
    public WeatherAPIException(String message, Throwable cause) {
        super(message, cause);
    }
}