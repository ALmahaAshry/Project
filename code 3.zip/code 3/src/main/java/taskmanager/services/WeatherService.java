package taskmanager.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import taskmanager.api.WeatherForecast;
import taskmanager.exceptions.WeatherAPIException;
/**
 * <b>Service Purpose: External API Integration & Caching</b>
 * <p>This service facilitates communication with the OpenWeatherMap API to retrieve 
 * real-time meteorological data. It implements a local caching mechanism to minimize 
 * redundant network requests and improve system responsiveness.</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Networking:</b> Utilizes {@link HttpURLConnection} for synchronous HTTP GET requests.</li>
 *   <li><b>Reactive I/O:</b> Offloads blocking network operations to the {@code boundedElastic} 
 *       scheduler to prevent Event Dispatch Thread (EDT) congestion[cite: 20].</li>
 *   <li><b>Data Parsing:</b> Performs manual string manipulation to extract specific 
 *       fields (temperature and condition) from JSON responses[cite: 20].</li>
 *   <li><b>State Management:</b> Maintains a memory-based {@link HashMap} for location-based 
 *       weather result persistence during the session[cite: 20].</li>
 * </ul>
 */
public class WeatherService {
    /** <b>Field:</b> Secret credential for OpenWeatherMap API authentication[cite: 20]. */
    private final String apiKey;
    /** <b>Field:</b> Local data store for caching previous API results indexed by location[cite: 20]. */
    private final Map<String, WeatherForecast> cache = new HashMap<>();
    /**
     * <b>Constructor: Service Initialization</b>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>A non-null API key must be provided to authorize external requests[cite: 20].</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>The service instance is allocated with the provided security credentials[cite: 20].</li>
     * </ul>
     * 
     * @param apiKey The credential string for the weather provider.
     */
    public WeatherService(String apiKey) {
        this.apiKey = apiKey;
    }
    /**
     * <b>Role: Asynchronous Weather Retrieval with Cache-Aside Logic</b>
     * <p>Initiates a weather data fetch operation. The method first checks the local 
     * cache before initiating an external network call.</p>
     * 
     * <p><b>Execution Logic:</b></p>
     * 1. Checks if the 'location' key exists in the internal {@code cache} map[cite: 20].
     * 2. If present, returns the cached {@link WeatherForecast} immediately[cite: 20].
     * 3. If absent, constructs a REST API URL and performs an HTTP GET request[cite: 20].
     * 4. Validates the HTTP response code; handles error streams if the code is not 200[cite: 20].
     * 5. Parses JSON data to extract temperature, weather conditions, and rain probability[cite: 20].
     * 6. Populates the cache with the new result for future requests[cite: 20].
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>'location' must be a valid geographic name supported by OpenWeatherMap[cite: 20].</li>
     *   <li>Internet connectivity must be established for non-cached requests[cite: 20].</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a {@link Mono} emitting a populated {@link WeatherForecast} object[cite: 20].</li>
     *   <li>The local cache is updated if a network request is successful[cite: 20].</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Network Consumption: Consumes bandwidth by making outbound HTTP connections[cite: 20].</li>
     *   <li>Memory Mutation: Modifies the internal 'cache' map[cite: 20].</li>
     *   <li>Thread Offloading: Moves processing to the {@code Schedulers.boundedElastic()} thread pool[cite: 20].</li>
     * </ul>
     * 
     * @param location The city or location string.
     * @return A Mono emitting the weather data or a {@link WeatherAPIException} on failure.
     * @throws WeatherAPIException if the API returns an error or network parsing fails[cite: 20].
     */
    public Mono<WeatherForecast> getWeather(String location) {

        return Mono.fromCallable(() -> {
            // Step 1: Optimization check
            // CACHE CHECK
            if (cache.containsKey(location)) {
                return cache.get(location);
            }
            
            String urlString =
                    "https://api.openweathermap.org/data/2.5/weather?q="
                            + location + "&appid=" + apiKey + "&units=metric";

            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int code = conn.getResponseCode();

            BufferedReader reader;
            
            if (code != 200) {
               
                reader = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream())
                );

                StringBuilder error = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    error.append(line);
                }

                reader.close();

                throw new WeatherAPIException(
                        "Weather API failed (HTTP " + code + "): " + error,
                        new RuntimeException(error.toString())
                );
            }

          
            reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
            );

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            reader.close();

            String json = sb.toString();
            // Entity mapping (Manual JSON traversal)
            double temp = Double.parseDouble(
                    json.split("\"temp\":")[1].split(",")[0]
            );

            String condition = json.split("\"main\":\"")[1].split("\"")[0];
            // Heuristic to simulate rain probability based on condition text
            double rain = condition.toLowerCase().contains("rain") ? 0.9 : 0.1;

            WeatherForecast forecast = new WeatherForecast(
                    location,
                    LocalDateTime.now(),
                    temp,
                    condition,
                    rain
            );
           
            cache.put(location, forecast);

            return forecast;

        })
        .subscribeOn(Schedulers.boundedElastic())
        .onErrorMap(e -> new WeatherAPIException("Weather fetch failed: " + e.getMessage(), e));
    }
}