package taskmanager.impl;

import java.util.ArrayList;
import java.util.List;
import reactor.core.publisher.Mono;
import taskmanager.api.*;
/**
 * <b>Implementation Purpose: Weather-Aware Planning</b>
 * <p>This class provides a concrete implementation of the {@link SchedulePlanner} interface. 
 * It contains the core decision-making logic that evaluates task safety based on specific 
 * meteorological thresholds (precipitation and temperature).</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Heuristic Logic:</b> Employs predefined thresholds (60% rain probability and 38°C temperature) 
 *       to classify tasks.</li>
 *   <li><b>Reactive Wrapping:</b> Uses {@link Mono#fromSupplier} to wrap synchronous calculation 
 *       logic into a reactive stream.</li>
 *   <li><b>Conditional Branching:</b> Differentiates between weather-sensitive and 
 *       non-weather-sensitive tasks during evaluation.</li>
 * </ul>
 * 
 * @see taskmanager.api.SchedulePlanner
 * @see taskmanager.api.ScheduleRecommendation
 */
/**
 * Weather-aware schedule planner implementation.
 * Uses weather data to recommend safe or risky task timings.
 */
public class DefaultSchedulePlanner implements SchedulePlanner {
    /**
     * <b>Role:</b> Core Scheduling Evaluation.
     * <p>Processes a collection of tasks and determines their suitability against 
     * a provided weather forecast.</p>
     * 
     * <p><b>Execution Logic:</b></p>
     * 1. Iterates through the {@link Task} list.
     * 2. If a task is not weather-sensitive, it is immediately marked as SAFE.
     * 3. For sensitive tasks, it checks:
     *    - Precipitation > 0.6 (60%): Marks as RISKY (Rain).
     *    - Temperature > 38°C: Marks as RISKY (Heat).
     *    - Otherwise: Marks as GOOD TIME.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>'tasks' list must not be null.</li>
     *   <li>'forecast' must be a valid, non-null object containing temperature and rain data.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Returns a {@link Mono} emitting a new {@link List} of {@link ScheduleRecommendation} objects.</li>
     *   <li>The input 'tasks' list and 'forecast' object remain unmodified (thread-safe).</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>None. This is a side-effect-free calculation method.</li>
     * </ul>
     * 
     * @param tasks List of tasks to be evaluated.
     * @param forecast The weather forecast to compare against.
     * @return A Mono emitting the evaluation results.
     */
    @Override
    public Mono<List<ScheduleRecommendation>> suggestSchedule(
            List<Task> tasks,
            WeatherForecast forecast
    ) {

        return Mono.fromSupplier(() -> {

            List<ScheduleRecommendation> result = new ArrayList<>();

            for (Task task : tasks) {

                //  non-weather-sensitive task
                // Logic for tasks that ignore weather conditions
                if (!task.isWeatherSensitive()) {
                    result.add(new ScheduleRecommendation(
                            task,
                            "SAFE (not weather sensitive)"
                    ));
                    continue;
                }

                // weather-sensitive logic
                // Threshold-based logic for environmental sensitivity
                double rain = forecast.getPrecipitationProbability();
                double temp = forecast.getTemperatureCelsius();

                if (rain > 0.6) {
                    result.add(new ScheduleRecommendation(
                            task,
                            "RISKY ❌ (high chance of rain)"
                    ));
                } else if (temp > 38) {
                    result.add(new ScheduleRecommendation(
                            task,
                            "RISKY ❌ (too hot)"
                    ));
                } else {
                    result.add(new ScheduleRecommendation(
                            task,
                            "GOOD TIME ✅ (weather is suitable)"
                    ));
                }
            }

            return result;
        });
    }
    /**
     * <b>Role:</b> Location-based Planning (Unsupported Implementation).
     * <p>This method is currently not implemented directly to enforce a separation 
     * of concerns between weather fetching and schedule planning.</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>None.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>Always returns a {@link Mono#error} containing an {@link UnsupportedOperationException}.</li>
     * </ul>
     * 
     * @param tasks List of tasks.
     * @param location Targeted geographic location.
     * @return A Mono signalling an error.
     * @throws UnsupportedOperationException As per the current implementation strategy.
     */
    @Override
    public Mono<List<ScheduleRecommendation>> suggestScheduleForLocation(
            List<Task> tasks,
            String location
    ) {

        
        return Mono.error(new UnsupportedOperationException(
                "Use fetchWeather(location) + suggestSchedule(tasks, forecast)"
        ));
    }
}