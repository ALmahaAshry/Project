package taskmanager.impl;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import taskmanager.api.*;
import taskmanager.exceptions.InvalidTaskException;
import taskmanager.exceptions.TaskNotFoundException;
/**
 * <b>Implementation Purpose: Thread-Safe In-Memory Storage</b>
 * <p>This class provides a concrete, reactive implementation of the {@link TaskService} 
 * interface using a concurrent in-memory map. It is designed to handle task 
 * persistence during the application's runtime without requiring an external database.</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Thread Safety:</b> Utilizes {@link ConcurrentHashMap} to manage concurrent access 
 *       from multiple reactive threads without explicit locking.</li>
 *   <li><b>Validation:</b> Enforces structural integrity by checking mandatory task attributes 
 *       before persistence.</li>
 *   <li><b>Reactive Streams:</b> Bridges standard collection operations with Project Reactor 
 *       types (Mono/Flux) for non-blocking I/O simulation.</li>
 * </ul>
 * 
 * @see taskmanager.api.TaskService
 * @see taskmanager.api.Task
 */
/**
 * Thread-safe in-memory implementation of TaskService.
 */
public class InMemoryTaskService implements TaskService {
    /** 
     * <b>Field:</b> Thread-safe storage for Task entities. 
     * Indexed by the Task's unique ID.
     */
    private final Map<String, Task> tasks = new ConcurrentHashMap<>();
    /**
     * <b>Role:</b> Synchronous Task Validation and Storage.
     * 
     * <p><b>Execution Logic:</b></p>
     * 1. Wraps the logic in a {@link Mono#fromRunnable}.
     * 2. Validates that both Task ID and Title are present.
     * 3. Inserts the task into the internal map.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The 'task' parameter must not be null.</li>
     *   <li>The task object must contain a non-null ID and Title.[cite: 19]</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>The task is successfully stored in memory.[cite: 19]</li>
     *   <li>Returns a Mono that signals completion upon success.[cite: 19]</li>
     * </ul>
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Updates the global state of the 'tasks' map.[cite: 19]</li>
     * </ul>
     * 
     * @param task The task object to be saved.
     * @return A Mono signalling completion.
     * @throws InvalidTaskException if ID or Title is missing.[cite: 19]
     */
    @Override
    public Mono<Void> addTask(Task task) {
        return Mono.fromRunnable(() -> {
            if (task.getId() == null || task.getTitle() == null) {
                throw new InvalidTaskException("Task ID and Title cannot be null");
            }
            tasks.put(task.getId(), task);
        });
    }
    /**
     * <b>Role:</b> Conditional Resource Deletion.
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>The 'taskId' must exist in the internal collection.[cite: 19]</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>The record associated with the ID is removed from memory.[cite: 19]</li>
     * </ul>
     * 
     * @param taskId Unique identifier for the task to be removed.
     * @return A Mono signalling successful removal.
     * @throws TaskNotFoundException if the key is not present in the map.[cite: 19]
     */
    @Override
    public Mono<Void> removeTask(String taskId) {
        return Mono.fromRunnable(() -> {
            if (!tasks.containsKey(taskId)) {
                throw new TaskNotFoundException(taskId);
            }
            tasks.remove(taskId);
        });
    }
    /**
     * <b>Role:</b> Targeted Retrieval with Error Handling.
     * 
     * @param taskId Target identifier.
     * @return A Mono emitting the found Task.
     * @throws TaskNotFoundException wrapped in a Mono error signal if not found.[cite: 19]
     */
    @Override
    public Mono<Task> findTaskById(String taskId) {
        return Mono.justOrEmpty(tasks.get(taskId))
                .switchIfEmpty(Mono.error(new TaskNotFoundException(taskId)));
    }
    /**
     * <b>Role:</b> Stream-based Retrieval.
     * @return A {@link Flux} emitting all current tasks as discrete events.[cite: 19]
     */
    @Override
    public Flux<Task> findAllTasks() {
        return Flux.fromIterable(tasks.values());
    }
    /**
     * <b>Role:</b> Collective Snapshot Retrieval.
     * <p>Creates a new ArrayList to provide a stable snapshot of the current state.</p>
     * 
     * @return A Mono emitting a List containing all tasks.[cite: 19]
     */
    @Override
    public Mono<List<Task>> findAllTasksAsList() {
        return Mono.fromSupplier(() -> new ArrayList<>(tasks.values()));
    }
}