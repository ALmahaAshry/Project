package taskmanager.impl;

import java.util.List;
import reactor.core.publisher.Mono;
import taskmanager.api.*;
import taskmanager.services.WeatherService;
/**
 * <b>Implementation Purpose: Central System Facade</b>
 * <p>This class provides the default implementation of the {@link TaskManager} interface. 
 * It acts as the central hub (Orchestrator) that connects the task storage service, 
 * the weather fetching service, and the scheduling logic.</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Dependency Injection:</b> Manually initializes concrete services in the constructor.</li>
 *   <li><b>Reactive Orchestration:</b> Manages the transition between reactive and synchronous calls.</li>
 *   <li><b>Facade Pattern:</b> Simplifies client interaction by exposing a unified set of methods 
 *       while hiding the underlying service complexity.</li>
 * </ul>
 */
/**
 * Default implementation of TaskManager.
 * Acts as the main facade connecting services.
 */
public class DefaultTaskManager implements TaskManager {
    /** <b>Field:</b> Service handling task persistence (e.g., In-memory). */
    private final TaskService taskService;
    /** <b>Field:</b> Logic component for weather-aware scheduling. */
    private final SchedulePlanner planner;
    /** <b>Field:</b> Service for external Weather API communication. */
    private final WeatherService weatherService;
    
    /**
     * <b>Constructor: System Bootstrap</b>
     * <p>Initializes the task manager by instantiating its core service dependencies.</p>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>'apiKey' must be a valid credentials string for the weather service provider.</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>An operational instance of DefaultTaskManager is created with all services ready.</li>
     * </ul>
     * 
     * @param apiKey The API key required for {@link WeatherService}.
     */
    public DefaultTaskManager(String apiKey) {
        this.taskService = new InMemoryTaskService();
        this.planner = new DefaultSchedulePlanner();
        this.weatherService = new WeatherService(apiKey);
    }
    /**
     * <b>Role:</b> Task Addition (Asynchronous fire-and-forget).
     * 
     * <b>Execution Logic:</b>
     * 1. Calls the reactive {@link TaskService#addTask(Task)} method.
     * 2. Subscribes to the resulting Mono to trigger the actual storage operation.
     * 
     * <b>Side Effects:</b>
     * <ul>
     *   <li>Subscription triggers an asynchronous execution on the reactor thread pool.</li>
     * </ul>
     * 
     * @param task The task to be added.
     */
    @Override
    public void addTask(Task task) {
        taskService.addTask(task).subscribe();
    }
    /**
     * <b>Role:</b> Task Removal (Asynchronous fire-and-forget).
     * 
     * @param taskId The ID of the task to be deleted.
     */
    @Override
    public void removeTask(String taskId) {
        taskService.removeTask(taskId).subscribe();
    }
    /**
     * <b>Role:</b> Synchronous Snapshot Retrieval.
     * 
     * <b>Execution Logic:</b>
     * 1. Fetches the task list via reactive service.
     * 2. Blocks the current thread until the full list is available (not recommended for 
     *    pure reactive systems, but used here for UI simplicity).[cite: 17]
     * 
     * @return A {@link List} of all managed tasks.
     */
    @Override
    public List<Task> getTasks() {
        return taskService.findAllTasksAsList().block();
    }
    /**
     * <b>Role:</b> Asynchronous Passthrough.
     * 
     * @param location The target city or location name.
     * @return A {@link Mono} emitting the fetched {@link WeatherForecast}.
     */
    @Override
    public Mono<WeatherForecast> fetchWeather(String location) {
        return weatherService.getWeather(location);
    }
    /**
     * <b>Role:</b> Service Accessor.
     * @return The internal {@link SchedulePlanner} instance.
     */
    @Override
    public SchedulePlanner getPlanner() {
        return planner;
    }
    /**
     * <b>Role:</b> Dependency Accessor (Internal/UI Use).
     * @return The underlying {@link TaskService} instance.
     */
    // Needed for UI access
    public TaskService getTaskService() {
        return taskService;
    }
}