package taskmanager.ui;

import java.awt.*;
import java.time.LocalDateTime;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import taskmanager.api.SchedulePlanner;
import taskmanager.api.ScheduleRecommendation;
import taskmanager.api.Task;
import taskmanager.api.TaskManager;
import taskmanager.api.TaskService;
import taskmanager.exceptions.TaskNotFoundException;
/**
 * <b>Class Purpose: Main UI Controller</b>
 * <p>This class serves as the primary graphical interface for the Smart Task Manager. 
 * It coordinates user actions (Add, Delete, Edit, Weather Update) with the underlying 
 * reactive API services while ensuring all UI modifications occur on the Event Dispatch Thread (EDT).</p>
 * 
 * <p><b>Technical Scope:</b></p>
 * <ul>
 *   <li><b>Dependency Injection:</b> Receives a {@link TaskManager} facade to access system logic.</li>
 *   <li><b>Reactive UI Binding:</b> Subscribes to reactive streams (Mono/Flux) and bridges them to Swing components[cite: 21].</li>
 *   <li><b>Concurrency Management:</b> Uses {@link Schedulers#boundedElastic()} for background processing 
 *       and {@link SwingUtilities#invokeLater} for thread-safe UI updates[cite: 21].</li>
 * </ul>
 */
public class SmartTaskManagerFrame extends JFrame {
    /** <b>Field:</b> Main facade for general operations[cite: 21]. */
    private final TaskManager taskManager;
    /** <b>Field:</b> Service used for direct reactive task lookups[cite: 21]. */
    private final TaskService taskService;
    /** <b>Field:</b> Component used for weather-based schedule evaluation[cite: 21]. */
    private final SchedulePlanner schedulePlanner;
/** <b>Field:</b> Swing table component for displaying task data[cite: 21]. */
    private final JTable taskTable;
    /** <b>Field:</b> Underlying data model for the task table[cite: 21]. */
    private final DefaultTableModel tableModel;
    /** <b>Field:</b> UI button to trigger weather-aware scheduling[cite: 21]. */
    private final JButton updateWeatherButton;
    /** <b>Field:</b> Status bar label for user notifications[cite: 21]. */
    private final JLabel statusLabel;
    /** <b>Field:</b> Configuration for table headers[cite: 21]. */
    private final String[] columnNames = {"ID", "Title", "Due Time", "Weather Sensitive", "Status"};
    /**
     * <b>Constructor: UI Initialization & Component Assembly</b>
     * 
     * <b>Pre-conditions:</b>
     * <ul>
     *   <li>A non-null {@link TaskManager} must be provided[cite: 21].</li>
     * </ul>
     * 
     * <b>Post-conditions:</b>
     * <ul>
     *   <li>The JFrame is configured, components are added to the layout, and initial tasks are loaded[cite: 21].</li>
     * </ul>
     * 
     * @param taskManager The system facade instance.
     */
    public SmartTaskManagerFrame(TaskManager taskManager) {
        this.taskManager = taskManager;
        // Explicit cast for implementation-specific service access
        this.taskService = ((taskmanager.impl.DefaultTaskManager) taskManager).getTaskService();
        this.schedulePlanner = taskManager.getPlanner();

        // Frame configuration
        setTitle("Smart Task Manager (Swing)");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(750, 400);
        setLocationRelativeTo(null);

        // Component initialization
        tableModel = new DefaultTableModel(columnNames, 0);
        taskTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(taskTable);

        updateWeatherButton = new JButton("Update Weather");
        updateWeatherButton.setEnabled(false);

        statusLabel = new JLabel(" Ready");
        // Layout assembly
        // ===== BUTTONS =====
        JButton addButton = new JButton("Add");
        JButton deleteButton = new JButton("Delete");
        JButton editButton = new JButton("Edit Title");

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(addButton);
        bottomPanel.add(deleteButton);
        bottomPanel.add(editButton);
        bottomPanel.add(updateWeatherButton);

        setLayout(new BorderLayout(5, 5));
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
        add(statusLabel, BorderLayout.NORTH);

        // Load tasks
        loadTasks();
        // Selection logic for button state
        // Enable weather button when row selected
        taskTable.getSelectionModel().addListSelectionListener(e -> {
            updateWeatherButton.setEnabled(taskTable.getSelectedRow() >= 0);
        });
        // Event Listeners for CRUD operations[cite: 21]
        // ===== ADD TASK =====
        addButton.addActionListener(e -> {
            Task t = new Task(
                    "task-" + System.currentTimeMillis(),
                    "New Task",
                    LocalDateTime.now().plusHours(2),
                    false
            );
            taskManager.addTask(t);
            loadTasks();
        });

        // ===== DELETE TASK =====
        deleteButton.addActionListener(e -> {
            int row = taskTable.getSelectedRow();
            if (row >= 0) {
                String id = (String) tableModel.getValueAt(row, 0);
                try {
                    taskManager.removeTask(id);
                    loadTasks();
                    statusLabel.setText(" Deleted task: " + id);
                } catch (TaskNotFoundException ex) {
                    statusLabel.setText(" Error: " + ex.getMessage());
                }
            }
        });

        // EDIT TASK 
        editButton.addActionListener(e -> {
            int row = taskTable.getSelectedRow();
            if (row >= 0) {
                String id = (String) tableModel.getValueAt(row, 0);
                String newTitle = JOptionPane.showInputDialog("Enter new title:");

                if (newTitle != null && !newTitle.trim().isEmpty()) {
                    taskService.findTaskById(id)
                            .subscribeOn(Schedulers.boundedElastic())
                            .subscribe(task -> {
                                task.setTitle(newTitle);
                                SwingUtilities.invokeLater(this::loadTasks);
                            }, error -> SwingUtilities.invokeLater(() ->
                                    statusLabel.setText(" Error: " + error.getMessage())
                            ));
                }
            }
        });

        // WEATHER BUTTON 
        updateWeatherButton.addActionListener(e -> {
            int row = taskTable.getSelectedRow();
            if (row < 0) return;

            String taskId = (String) tableModel.getValueAt(row, 0);
            updateWeatherForTask(taskId);
        });
    }
    /**
     * <b>Role: Asynchronous Data Loading</b>
     * <p>Fetches the current task list from the manager in a background thread and schedules a UI refresh[cite: 21].</p>
     */
    private void loadTasks() {
        Mono.just(taskManager.getTasks())
                .subscribeOn(Schedulers.boundedElastic())
                .doOnNext(tasks -> SwingUtilities.invokeLater(() -> populateTable(tasks)))
                .subscribe();
    }
    /**
     * <b>Role: UI Data Synchronization</b>
     * <p>Clears and repopulates the table model with the provided list of tasks[cite: 21].</p>
     * <b>Pre-conditions:</b> Must be called on the Event Dispatch Thread (EDT).
     * @param tasks The current collection of tasks.
     */
    private void populateTable(List<Task> tasks) {
        tableModel.setRowCount(0);
        for (Task t : tasks) {
            tableModel.addRow(new Object[]{
                    t.getId(),
                    t.getTitle(),
                    t.getDueDateTime(),
                    t.isWeatherSensitive(),
                    "N/A"
            });
        }
    }
    /**
     * <b>Role: Reactive Orchestration of Weather and Scheduling</b>
     * <p>Chains weather fetching and schedule recommendation logic, updating the UI with results[cite: 21].</p>
     * <b>Side Effects:</b> Modifies the 'Status' column in the UI table for all relevant tasks.
     * @param taskId The ID of the task that triggered the update.
     */
    private void updateWeatherForTask(String taskId) {

        taskManager.fetchWeather("Jeddah")
                .flatMap(forecast ->
                        schedulePlanner.suggestSchedule(taskManager.getTasks(), forecast)
                )
                .subscribeOn(Schedulers.boundedElastic())
                .doOnError(error -> SwingUtilities.invokeLater(() ->
                        statusLabel.setText(" Error: " + error.getMessage())
                ))
                .subscribe(recommendations -> SwingUtilities.invokeLater(() -> {

                    for (ScheduleRecommendation rec : recommendations) {
                        updateTaskStatusInTable(
                                rec.task().getId(),
                                rec.recommendation()
                        );
                    }

                    statusLabel.setText(" Weather + Schedule updated");
                }));
    }
    /**
     * <b>Role: Local UI Update</b>
     * <p>Locates a row by ID and updates its status string[cite: 21].</p>
     * @param taskId The target task identifier.
     * @param status The recommendation text to display.
     */
    private void updateTaskStatusInTable(String taskId, String status) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(taskId)) {
                tableModel.setValueAt(status, i, 4);
                break;
            }
        }
    }
}